import * as React from 'react';
 

interface OwnProps {}
 

const test: React.SFC<OwnProps> = props => {

 return <h1>Hello world!</h1>;

};
 

export default test;