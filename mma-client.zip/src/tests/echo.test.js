import React from 'react';
import chai, { expect } from 'chai';
import App from '../App';
import chaiEnzyme from 'chai-enzyme';

describe('Dummy test block:', function() {
    /* Yes, i know that this test is nonse :-) */
    it('should pass dummy test', () =>{
        expect(true).to.be.true;
    })
})
