import React, { useEffect } from 'react';
import { useFetchEvent } from '../../core/helpers';
import { apiRoutes } from '../../core/api-routes';
import { IUFCEvent } from '../../store/types';
import { SingleBarChart, CircleChart } from '../../Ui/charts';


interface ISingleEventProps {
    match: {
        params: {
            id: number
        }
    }
}

const SingleEvent: React.FC<ISingleEventProps> = (props: ISingleEventProps) => {

    const event: IUFCEvent = useFetchEvent(apiRoutes.eventPage(props.match.params.id.toString()));
    // useEffect(() => {
    //     if(event) {
    //         console.log('Event loaded!');
    //     }
    // }, []);

    const fighterData = {
        wins:10,
        defeats:11
    };

    const loadedEvent = (event: IUFCEvent) => {
        const { title } = event;
        return (
            <div>
                Event {title} is loaded!
                <div>
                    <SingleBarChart  a={10} b={2}/>
                    <CircleChart a={15} b={25} label={'TKO'}/>
                </div>
        </div>
        )
    }

    return (
        <div className="page">
            {
                event ? loadedEvent(event) : null
            }
        </div>
    );
}

export default SingleEvent;