import React from 'react';

const Fighters: React.FC = () => {
  return (
    <div className="page">
        <h1>Fighters!!!</h1>
    </div>
  );
}

export default Fighters;
