module.exports = function (api) {
    //we will keep here all the supplementary babel options
    api.cache(false); 
    return {
        "env": {
            "test" : {
              "compact": false
            }
          }
    }
};

